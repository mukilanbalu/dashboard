import React, { Component } from 'react';
import './App.css';
import Sidebar from './sidebar';
import User from './user';
import Udetails from './udetails';
import Nav from'./nav-bar';


class App extends Component {
  render() {
    return (
      <div className="App">
          <div className="row">
            <div className="col-12 d-flex  px-0">
                <div className="col-2 pr-0">
                    <Sidebar />
                    </div>
                    <div className="col-10 px-0">
                    <Nav/>
                    <div className="row">
                    <User />
                    <Udetails/>
                    </div>
                    </div>
                </div>
            </div>
          </div>
   
     
    );
  }
}

export default App;
